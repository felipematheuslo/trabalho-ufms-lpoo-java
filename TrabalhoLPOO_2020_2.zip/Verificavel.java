interface Verificavel{
  boolean validar(String codigo);
  void solicitarNovo();
}